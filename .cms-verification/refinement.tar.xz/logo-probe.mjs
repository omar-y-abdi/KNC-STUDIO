import { chromium, webkit } from 'playwright'
import { writeFile } from 'node:fs/promises'
import { nativeBackend } from './cms-native.mjs'
const out = process.env.CMS_EVIDENCE_DIR ?? '/tmp/cms-workspace'
const report = []
for (const [engine, name] of [[chromium, 'chromium'], [webkit, 'webkit']]) {
  const browser = await engine.launch()
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, reducedMotion: 'reduce' })
  await nativeBackend(context)
  const page = await context.newPage()
  const base = process.env.BASE_URL ?? 'http://127.0.0.1:4188'
  try {
    await page.goto(`${base}/tools/e2e/admin-harness.html?view=cms-studio`)
    await page.evaluate(async () => (await import('/tools/e2e/admin-harness.tsx')).mountCmsStudioHarness())
    await page.locator('.cms-canvas-shell').waitFor({ timeout: 90000 })
    const frame = page.frameLocator('.gjs-frame').first()
    await frame.locator('[data-knc-surface="desktop-home"]').waitFor()
    await page.locator('#cms-library').getByRole('button', { name: 'Bokning', exact: true }).click()
    await page.getByRole('button', { name: 'Mobil', exact: true }).click()
    await page.getByRole('button', { name: 'Fit', exact: true }).click()
    const lettering = frame.locator('[data-knc-surface="mobile-booking"] svg text').filter({ hasText: /^BNB$/ }).first()
    await lettering.waitFor()
    const logoId = await lettering.evaluate(n => n.ownerSVGElement.id)
    const logo = frame.locator(`[id="${logoId}"]`)
    for (const events of ['auto', 'all', 'bounding-box']) {
      const hit = await logo.evaluate((node, events) => {
        const style = node.ownerDocument.createElement('style')
        style.textContent = `svg{pointer-events:${events}!important}`
        node.ownerDocument.head.append(style)
        const box = node.getBoundingClientRect()
        const positions = [[3,3],[box.width/2,box.height/2]]
        const hits = positions.map(([x,y]) => {
          const target = node.ownerDocument.elementFromPoint(box.left + x, box.top + y)
          return { x,y,id:target?.id, tag:target?.tagName, inLogo:node.contains(target) }
        })
        return { events, logoId:node.id, width:box.width, height:box.height, hits }
      }, events)
      await logo.click({ position: { x: 3, y: 3 } })
      report.push({ engine: name, ...hit, logoControls: await page.locator('#cms-inspector').getByLabel('Logotyptext 1', { exact: true }).count() })
      await page.screenshot({ path: `${out}/logo-probe-${name}-${events}.png` })
    }
  } catch (error) { report.push({ engine:name, error:error.message }) }
  finally { await browser.close() }
}
await writeFile(`${out}/logo-probe.json`, JSON.stringify(report, null, 2))
console.log(JSON.stringify(report, null, 2))
