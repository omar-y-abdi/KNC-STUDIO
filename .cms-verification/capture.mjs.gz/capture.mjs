import { mkdir, writeFile } from 'node:fs/promises'
import { chromium, webkit } from 'playwright'
import { nativeBackend } from './cms-native.mjs'
import { emptyDocument, EMAIL_NAMES, defaultEmailDesign } from '../../shared/cms.ts'
import { defaultEmailTemplate } from '../../supabase/functions/_shared/email.ts'

const base = process.env.BASE_URL ?? 'http://127.0.0.1:4188'
const out = process.env.CMS_EVIDENCE_DIR ?? '/tmp/cms-workspace'
await mkdir(`${out}/surfaces`, { recursive: true })
const report = []
const failures = []
const sampleAssets = ['Salongens logotyp', 'Salongen – tidigare version', 'Tidigare omslag'].map((name, i) => ({
  id: `22222222-2222-4222-8222-${String(i + 1).padStart(12, '0')}`,
  bucket: 'gallery', path: `logo/22222222-2222-4222-8222-${String(i + 1).padStart(12, '0')}.webp`,
  name, alt: 'Blade & Blend Studio', mime: 'image/webp', bytes: 45000, width: 1200, height: 630,
  archived: i > 0, ...(i === 2 ? { trashed_at: '2026-09-20T10:00:00Z' } : {}), version: 1,
}))
function seedDocument() {
  const seed = emptyDocument()
  seed.settings = { ...seed.settings, business_name: 'Blade & Blend Studio', business_email: 'salong@example.com', business_city: 'Göteborg' }
  seed.emails = EMAIL_NAMES.flatMap(template => ['sv', 'en'].map(lang => {
    const copy = defaultEmailTemplate(template, lang)
    return { template, lang, subject: copy.subject, preheader: copy.preheader, title: copy.title, intro: copy.intro, section_title: copy.sectionTitle, note: copy.note, cta_label: copy.ctaLabel, contact_lead: copy.contactLead, design: defaultEmailDesign() }
  }))
  return seed
}
for (const [engine, name] of [[chromium, 'chromium'], [webkit, 'webkit']]) {
  const browser = await engine.launch()
  try {
    for (const width of [1440, 390]) {
      const context = await browser.newContext({ viewport: { width, height: width === 1440 ? 900 : 844 }, reducedMotion: 'reduce' })
      context.setDefaultTimeout(12000)
      await nativeBackend(context, seedDocument(), sampleAssets)
      await context.route('**/storage/v1/object/public/**', route => route.fulfill({ path: 'public/og-image.png', contentType: 'image/png' }))
      await context.route('**/functions/v1/cms-studio', route => {
        if (route.request().method() !== 'POST' || route.request().postDataJSON().operation !== 'asset_usage') return route.fallback()
        return route.fulfill({ headers: { 'Access-Control-Allow-Origin': new URL(base).origin }, json: { currentReferences: 0, historyReferences: 0 } })
      })
      const page = await context.newPage()
      const prefix = `${name}-${width}`
      const errors = []
      page.on('pageerror', error => errors.push(error.message))
      const shot = async state => {
        await page.evaluate(async () => { await globalThis.document.fonts.ready })
        await page.screenshot({ path: `${out}/surfaces/${prefix}-${state}.png`, animations: 'disabled' })
        const metrics = await page.evaluate(() => ({
          overflow: globalThis.document.documentElement.scrollWidth > globalThis.innerWidth,
          modal: globalThis.document.querySelectorAll('[aria-modal="true"],dialog[open]').length,
        }))
        report.push({ engine: name, width, state, ...metrics })
        if (metrics.overflow) failures.push(`${prefix}/${state}: horizontal page overflow`)
      }
      const mount = async () => {
        await page.goto(`${base}/tools/e2e/admin-harness.html?view=cms-studio`)
        await page.evaluate(async () => (await import('/tools/e2e/admin-harness.tsx')).mountCmsStudioHarness())
        await page.locator('.cms-canvas-shell').waitFor({ timeout: 90000 })
        await page.frameLocator('.gjs-frame').first().locator(`[data-knc-surface="${width <= 900 ? 'mobile-home' : 'desktop-home'}"]`).waitFor()
      }
      const menu = async () => {
        if (width <= 900) await page.locator('.cms-mobile-tools').getByRole('button', { name: 'Sidor', exact: true }).click()
      }
      const closePanel = async () => {
        if (width <= 900) await page.getByRole('button', { name: 'Stäng panel', exact: true }).click()
      }
      const props = async () => {
        if (width <= 900) await page.locator('.cms-mobile-tools').getByRole('button', { name: 'Egenskaper', exact: true }).click()
      }
      const journey = async (state, fn) => {
        try { await fn() } catch (error) {
          failures.push(`${prefix}/${state}: ${error.message}`)
          await shot(`failure-${state}`).catch(() => undefined)
          await mount()
        }
      }
      try {
        await mount()
        await journey('canvas', async () => {
          await shot('canvas-notice')
          await page.getByRole('button', { name: 'Stäng meddelande', exact: true }).click()
          await page.getByRole('button', { name: 'Fit', exact: true }).click()
          await shot('canvas-light')
          await page.getByRole('button', { name: 'Mörk', exact: true }).click()
          await shot('canvas-dark')
          await page.getByRole('button', { name: 'Ljus', exact: true }).click()
          await page.getByRole('button', { name: 'Jämför', exact: true }).click()
          await page.locator('.cms-compare-pane').waitFor()
          await shot('canvas-compare')
          await page.getByRole('button', { name: 'Jämför', exact: true }).click()
        })
        await journey('library', async () => {
          await menu()
          await shot('library')
          await page.getByRole('searchbox', { name: 'Sök sidor' }).fill('Hittas inte')
          await shot('library-search-empty')
          await page.getByRole('button', { name: 'Rensa sökning', exact: true }).click()
          await closePanel()
        })
        await journey('inspector', async () => {
          await props()
          for (const [tab, state] of [['Design','page-properties'],['Lager','layers'],['Lägg till','blocks']]) {
            await page.getByRole('tab', { name: tab, exact: true }).click()
            await shot(state)
          }
          await page.getByRole('tab', { name: 'Design', exact: true }).click()
          await closePanel()
        })
        await journey('page-dialog', async () => {
          await menu()
          await page.getByRole('button', { name: '+ Ny sida', exact: true }).click()
          await page.getByRole('dialog', { name: 'Ny sida', exact: true }).waitFor()
          await shot('new-page')
          await page.getByRole('textbox', { name: 'Adress', exact: true }).fill('/admin')
          await page.getByRole('button', { name: 'Skapa sida', exact: true }).click()
          await page.getByRole('dialog').getByRole('alert').waitFor()
          await shot('new-page-validation')
          await page.keyboard.press('Escape')
          const dismiss = page.getByRole('button', { name: 'Stäng', exact: true })
          if (await dismiss.isVisible()) await dismiss.click()
        })
        await journey('backup', async () => {
          await menu()
          await page.getByRole('button', { name: 'Utkast & backup', exact: true }).click()
          await page.getByRole('dialog', { name: 'Utkast & backup', exact: true }).waitFor()
          await shot('backup')
          await page.keyboard.press('Escape')
        })
        for (const [trigger, title, state] of [
          ['Resurser', 'Bilder & typsnitt', 'resources'],
          ['Business / SEO', 'Företag & sökresultat', 'business'],
          ['Mejl', 'Mejl från din salong', 'email'],
          ['◐ Webbplatsens stil', 'Webbplatsens stil', 'theme'],
        ]) await journey(state, async () => {
          await menu()
          await page.getByRole('button', { name: trigger, exact: true }).click()
          const region = page.getByRole('region', { name: title, exact: true })
          await region.waitFor()
          await shot(state)
          if (state === 'resources') {
            await region.getByRole('button', { name: /Salongens logotyp/ }).click()
            await region.locator('.cms-resource-detail').waitFor()
            await region.locator('.cms-resource-detail').scrollIntoViewIfNeeded()
            await shot('resource-detail')
            await region.getByRole('searchbox', { name: 'Sök resurser' }).fill('no-resource')
            await shot('resource-search-empty')
            await region.getByRole('searchbox', { name: 'Sök resurser' }).fill('')
            for (const status of ['Arkiverade','Papperskorg']) {
              await region.getByRole('button', { name: status, exact: true }).click()
              await shot(`resources-${status === 'Arkiverade' ? 'archived' : 'trash'}`)
            }
          } else if (state === 'business') {
            await region.getByText('Sökresultat', { exact: true }).scrollIntoViewIfNeeded()
            await shot('business-seo')
          } else if (state === 'email') {
            await region.getByText('Utseende', { exact: true }).click()
            await shot('email-design')
            await region.getByText('Utseende', { exact: true }).click()
            if (width <= 900) await region.getByRole('button', { name: 'Förhandsvisa', exact: true }).click()
            await region.locator('.cms-email-preview').scrollIntoViewIfNeeded()
            await shot('email-preview')
          } else if (state === 'theme') {
            await region.getByRole('button', { name: 'Mörkt tema', exact: true }).click()
            await shot('theme-dark')
            await region.getByRole('button', { name: 'Ljust tema', exact: true }).click()
            await region.locator('.cms-theme-preview').scrollIntoViewIfNeeded()
            await shot('theme-preview')
          }
          await region.getByRole('button', { name: 'Tillbaka till sidan', exact: true }).click()
        })
        await journey('history', async () => {
          await page.getByRole('button', { name: 'Save / Publicera', exact: true }).click()
          await page.waitForFunction(() => globalThis.document.querySelector('.cms-status')?.textContent?.includes('Publicerad'))
          await page.getByRole('button', { name: 'History', exact: true }).click()
          const region = page.getByRole('region', { name: 'Webbplatsens historik', exact: true })
          await region.getByRole('button', { name: 'Granska', exact: true }).first().waitFor()
          await shot('history')
          await region.getByRole('button', { name: 'Granska', exact: true }).first().click()
          await page.getByRole('dialog').waitFor()
          await shot('history-review')
          await page.keyboard.press('Escape')
          await region.getByRole('button', { name: 'Tillbaka till sidan', exact: true }).click()
        })
        if (errors.length) failures.push(`${prefix}: browser errors ${errors.join('; ')}`)
      } finally { await context.close() }
    }
  } finally { await browser.close() }
}
await writeFile(`${out}/surface-coverage.json`, JSON.stringify({ report, failures }, null, 2))
console.log(JSON.stringify({ screenshots: report.length, failures }, null, 2))
if (failures.length) process.exitCode = 1
